// Completar antes de publicar. Nunca pongas la service_role key aquí.
window.NANNO_CONFIG={SUPABASE_URL:"https://TU-PROYECTO.supabase.co",SUPABASE_ANON_KEY:"TU_ANON_KEY"};
