# Nanno Café Fidelidad — versión real

Aplicación web responsive para usar desde distintos celulares, con Supabase como base online.

## Arquitectura
Cliente → QR único → celular de Nanno Café → escaneo → consulta online → +1 café → PostgreSQL.

Regla: 4 cafés comprados → se habilita el 5.º gratis.

El QR solo identifica al cliente; nunca contiene el saldo.

## Configuración
1. Crear proyecto en Supabase.
2. Ejecutar `supabase.sql` completo en SQL Editor.
3. Crear un usuario administrador en Authentication → Users.
4. Copiar `config.example.js` como `config.js` y completar URL + anon key.
5. Publicar la carpeta en un hosting HTTPS.

No uses la `service_role` key en el navegador.
